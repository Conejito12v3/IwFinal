namespace Aplicacion.ClasesDto;

public class CategoriaProductoDto
{
    public Guid? categoriaProductoId { get; set; }
    public string? nombre { get; set; }
}