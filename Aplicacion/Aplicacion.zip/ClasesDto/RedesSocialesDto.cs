namespace Aplicacion.ClasesDto;

public class RedesSocialesDto
{
    public Guid? redesSocialesId { get; set; }
    public string? facebook { get; set; }
    public string? instagram { get; set; }
    public string? twitter { get; set; }
    public string? youtube { get; set; }
    public string? tiktok { get; set; }
}