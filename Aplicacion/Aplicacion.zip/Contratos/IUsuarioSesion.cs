namespace Aplicacion.Contratos;

public interface IUsuarioSesion
{
    string ObtenerUsuarioSesion();
}